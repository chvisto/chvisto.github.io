# uart_protocol.py
# Team 305 EGR314, UART protocol layer v4.0
# MicroPython / ESP32-S3
# pure protocol, no sensor/display/motor logic

import struct
from team_config import (
    MY_ID, BCAST, KNOWN_IDS,
    PKT_LEN, PREFIX, SUFFIX,
    reserved_bytes_for
)

# bytes this node must stuff to avoid frame marker collisions
_RESERVED = reserved_bytes_for(MY_ID)

# RX state machine states
_ST_WAIT_P1 = 0   # hunting 0xA5
_ST_WAIT_P2 = 1   # hunting 0x5A
_ST_COLLECT = 2   # filling 64-byte frame

def _err(code, msg, raw=None):
    # tagged error, optional first 8 raw bytes
    if raw:
        snippet = ' '.join('{:02X}'.format(b) for b in raw[:8])
        print('[ERR {}] {} -- raw: {}'.format(code, msg, snippet))
    else:
        print('[ERR {}] {}'.format(code, msg))

def build_packet(receiver_id, msg_type, data_bytes=b''):
    # build a stuffed 64-byte packet, None on error
    if receiver_id == 0x00:
        # 0x00 means unset, can't send to nobody
        _err('E08', 'receiver ID is 0x00 (unset)')
        return None
    if receiver_id not in KNOWN_IDS:
        _err('E05', 'unknown receiver 0x{:02X}'.format(receiver_id))
        return None
    if len(data_bytes) > 57:
        # 64 total minus 7 overhead bytes = 57 payload max
        _err('E07', 'payload too long: {} bytes'.format(len(data_bytes)))
        return None

    pkt = bytearray(PKT_LEN)
    pkt[0] = PREFIX[0]   # start byte 1
    pkt[1] = PREFIX[1]   # start byte 2
    pkt[2] = MY_ID       # sender ID
    pkt[3] = receiver_id # dest ID
    pkt[4] = msg_type    # message type
    for i, b in enumerate(data_bytes):
        if 5 + i >= 62:
            # don't overwrite suffix positions
            break
        pkt[5 + i] = b

    # stuff reserved bytes, replace with (val-1) mod 256
    for i in range(4, 62):
        if pkt[i] in _RESERVED:
            pkt[i] = (pkt[i] - 1) & 0xFF

    pkt[62] = SUFFIX[0]  # stop byte 1
    pkt[63] = SUFFIX[1]  # stop byte 2
    return pkt

def validate_packet(pkt):
    # check frame structure and IDs, True if legit
    if len(pkt) != PKT_LEN:
        _err('E03', 'bad length: {}'.format(len(pkt)), pkt)
        return False
    if pkt[0] != PREFIX[0] or pkt[1] != PREFIX[1]:
        _err('E01', 'missing start bits', pkt)
        return False
    if pkt[62] != SUFFIX[0] or pkt[63] != SUFFIX[1]:
        _err('E02', 'missing stop bits', pkt)
        return False
    sender   = pkt[2]
    receiver = pkt[3]
    # zero ID means something's unconfigured
    if sender == 0x00 or receiver == 0x00:
        _err('E08', 'zero ID sender=0x{:02X} receiver=0x{:02X}'.format(
            sender, receiver), pkt)
        return False
    if sender not in KNOWN_IDS:
        _err('E04', 'sender ID not in loop: 0x{:02X}'.format(sender), pkt)
        return False
    if receiver not in KNOWN_IDS:
        _err('E05', 'receiver ID not in loop: 0x{:02X}'.format(receiver), pkt)
        return False
    # drop echoes of our own packets
    if sender == MY_ID:
        _err('E09', 'loopback -- discarding own packet', pkt)
        return False
    return True

def route_packet(pkt, handle_fn, send_ack_fn, forward_fn):
    # dispatch based on dest: local, broadcast, or forward
    sender   = pkt[2]
    receiver = pkt[3]
    msg_type = pkt[4]
    payload  = bytes(pkt[5:62])

    if receiver == MY_ID:
        # addressed to us, handle + ACK, no forward
        handle_fn(msg_type, payload, sender)
        send_ack_fn(sender, msg_type)

    elif receiver == BCAST:
        # broadcast: handle locally AND keep forwarding
        handle_fn(msg_type, payload, sender)
        forward_fn(pkt)

    else:
        # not ours, pass it along
        forward_fn(pkt)

def build_ack(dest, received_type):
    # ACK = msg_type 0xAA, payload is the echoed msg_type
    return build_packet(dest, 0xAA, bytes([received_type]))

class UARTReceiver:
    # RX state machine: WAIT_P1 -> WAIT_P2 -> COLLECT -> validate
    # call feed(uart) every main loop, before TX
    def __init__(self):
        self._state     = _ST_WAIT_P1
        self._buf       = bytearray(PKT_LEN)
        self._idx       = 0
        self.rx_count   = 0  # good packets
        self.drop_count = 0  # failed validation
        self.fwd_count  = 0  # packets forwarded

    def feed(self, uart):
        # drain RX FIFO byte-by-byte, return list of valid packets
        packets = []
        while uart.any():
            b = uart.read(1)
            if not b:
                break
            byte = b[0]

            if self._state == _ST_WAIT_P1:
                # looking for first prefix byte
                if byte == PREFIX[0]:
                    self._state = _ST_WAIT_P2

            elif self._state == _ST_WAIT_P2:
                if byte == PREFIX[1]:
                    # got full prefix, init buffer and collect
                    self._buf = bytearray(PKT_LEN)
                    self._buf[0] = PREFIX[0]
                    self._buf[1] = PREFIX[1]
                    self._idx  = 2
                    self._state = _ST_COLLECT
                elif byte == PREFIX[0]:
                    # repeated prefix, stay in WAIT_P2
                    pass
                else:
                    # junk between frames, restart
                    self._state = _ST_WAIT_P1

            elif self._state == _ST_COLLECT:
                # fill buffer until we hit full packet length
                self._buf[self._idx] = byte
                self._idx += 1
                if self._idx == PKT_LEN:
                    raw = bytes(self._buf)
                    # reset early so next frame isn't lost
                    self._state = _ST_WAIT_P1
                    self._idx   = 0
                    if validate_packet(raw):
                        self.rx_count += 1
                        packets.append(raw)
                    else:
                        self.drop_count += 1

        return packets
