# teammate node IDs
LIAM_ID    = 0x4C
ISAIAH_ID  = 0x49
ARIANNA_ID = 0x41
MYLES_ID   = 0x4D

WIFI_NETWORKS = [
    ('SETUP-6B60',  'fifty0382artist'),  # home
    ('photon',      'particle'),         # school lab Peralta 103
]
