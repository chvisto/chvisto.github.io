import network, ntptime, random
import uasyncio as asyncio
from machine import Pin, SoftI2C, UART
import ssd1306, time
from config import *

def pick_wifi():
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    try:
        visible = {ap[0].decode() for ap in sta.scan()}
    except:
        visible = set()
    for ssid, pw in WIFI_NETWORKS:
        if ssid in visible:
            print('WiFi selected:', ssid)
            return ssid, pw
    print('WiFi fallback:', WIFI_NETWORKS[0][0])
    return WIFI_NETWORKS[0]

_wifi_ssid, _wifi_pw = pick_wifi()

# oled setup, rotated 180
i2c  = SoftI2C(scl=Pin(42), sda=Pin(41))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)
oled.write_cmd(0xa0)
oled.write_cmd(0xc0)
W, H = 128, 64

uart = UART(1, baudrate=9600, tx=Pin(43), rx=Pin(44))

led_tx    = Pin(2, Pin.OUT, value=0)   # blue  - lights when we send
led_rx    = Pin(1, Pin.OUT, value=0)   # green - lights when we receive
led_debug = Pin(4, Pin.OUT, value=0)   # white

btn_up    = Pin(5,  Pin.IN, Pin.PULL_UP)
btn_left  = Pin(6,  Pin.IN, Pin.PULL_UP)
btn_right = Pin(7,  Pin.IN, Pin.PULL_UP)
btn_down  = Pin(15, Pin.IN, Pin.PULL_UP)
btn_start = Pin(17, Pin.IN, Pin.PULL_UP)
btn_stop  = Pin(16, Pin.IN, Pin.PULL_UP)
btn_sel   = Pin(18, Pin.IN, Pin.PULL_UP)
btn_debug = Pin(8,  Pin.IN, Pin.PULL_UP)

_BTNS = {
    'up': btn_up, 'dn': btn_down, 'lt': btn_left, 'rt': btn_right,
    'sel': btn_sel, 'start': btn_start, 'stop': btn_stop, 'dbg': btn_debug
}
_prev = {k: b.value() for k, b in _BTNS.items()}

# returns true only on the falling edge so it doesnt repeat
def pressed(key):
    cur = _BTNS[key].value()
    edge = (cur == 0 and _prev[key] == 1)
    _prev[key] = cur
    return edge

# flush after animations so held buttons dont re-trigger
def flush_btns():
    for k in _prev:
        _prev[k] = _BTNS[k].value()

# auto-repeat for scroll buttons - first press triggers immediately, repeats after hold
_held_since = {}
_last_repeat = {}
_HOLD_DELAY  = 400   # ms before repeat kicks in
_REPEAT_MS   = 120   # ms between repeats

def held(key):
    cur = _BTNS[key].value() == 0
    now = time.ticks_ms()
    if cur:
        if key not in _held_since:
            _held_since[key] = now
            _last_repeat[key] = now
            return True
        elif time.ticks_diff(now, _held_since[key]) > _HOLD_DELAY:
            if time.ticks_diff(now, _last_repeat[key]) > _REPEAT_MS:
                _last_repeat[key] = now
                return True
    else:
        _held_since.pop(key, None)
        _last_repeat.pop(key, None)
    return False

_lcd_changed_at = 0
lcd_on      = False
tx_enabled  = True
sel         = 0
view_top    = 0
in_sub          = False
in_values_sub   = False
values_sel      = 0
in_settings_sub  = False
settings_sel     = 0
_sysinfo_scroll  = 0
debug_mode      = False
VISIBLE     = 4
motor_speed = 0
motor_dir   = "FWD"
wifi_connected = False
last_rx_raw = ""
last_rx_type = "--"

_pkt_rx   = 0
_pkt_fwd  = 0
_pkt_drop = 0

values = {
    "temp": "--", "humid": "--", "motion": "--", "object_code": "--",
    "gyro_x": "--", "gyro_y": "--", "gyro_z": "--",
    "distance": "--", "speed": "0%", "motor": "OFF", "batt": "--"
}

MENU = ["Motor Ctrl", "Values", "Env Sensor", "Camera", "Distance", "Gyro Data", "TX Monitor", "Play Game", "Settings"]

def clr():   oled.fill(0)
def show():  oled.show()

def header(title):
    oled.fill_rect(0, 0, W, 11, 1)
    x = max(0, (W - len(title) * 8) // 2)
    oled.text(title, x, 2, 0)

def footer(hint):
    oled.hline(0, H - 10, W, 1)
    oled.text(hint[:16], 0, H - 8)

def draw_menu():
    global view_top
    if sel < view_top:              view_top = sel
    elif sel >= view_top + VISIBLE: view_top = sel - VISIBLE + 1
    clr()
    header("HMI CTRL")
    for i in range(VISIBLE):
        idx = view_top + i
        if idx >= len(MENU): break
        y = 13 + i * 12
        if idx == sel:
            oled.fill_rect(0, y - 1, W - 4, 11, 1)
            oled.text(">" + MENU[idx], 2, y, 0)
        else:
            oled.text(" " + MENU[idx], 2, y)
    bar_h = max(4, (H - 13) * VISIBLE // len(MENU))
    bar_y = 13 + ((H - 13 - bar_h) * view_top // max(1, len(MENU) - VISIBLE))
    oled.rect(W - 3, 13, 3, H - 13, 1)
    oled.fill_rect(W - 2, bar_y, 2, bar_h, 1)
    show()

def page_motor():
    clr(); header("MOTOR CTRL")
    spd_abs   = abs(motor_speed)
    direction = "FWD" if motor_speed >= 0 else "REV"
    oled.text("Speed: {:3d}%".format(spd_abs), 2, 13)
    bar_w = max(1, (W - 6) * spd_abs // 100) if spd_abs > 0 else 0
    oled.rect(2, 23, W - 6, 7, 1)
    if bar_w: oled.fill_rect(2, 23, bar_w, 7, 1)
    oled.text("Dir:  " + direction, 2, 33)
    oled.text("UP/DN:spd L/R:dir", 0, 43)
    footer("SEL=back")
    show()

def page_values():
    clr(); header("VALUES")
    oled.text("Temp:   " + str(values["temp"]), 2, 13)
    oled.text("Humid:  " + str(values["humid"]), 2, 24)
    oled.text("Dist:   " + str(values["distance"]), 2, 35)
    oled.text("Motion: " + str(values["motion"]), 2, 46)
    footer("SEL=back")
    show()

def page_env():
    clr(); header("ENV SENSOR")
    oled.text("Temp:  " + str(values["temp"]), 2, 16)
    oled.text("Humid: " + str(values["humid"]), 2, 32)
    footer("SEL=back")
    show()

def page_camera():
    clr(); header("CAMERA")
    oled.text("Motion: " + str(values["motion"]), 2, 16)
    oled.text("Object: " + str(values["object_code"]), 2, 32)
    footer("SEL=back")
    show()

def page_distance():
    clr(); header("DISTANCE")
    oled.text("Dist: " + str(values["distance"]) + " cm", 2, 24)
    footer("SEL=back")
    show()

def page_gyro():
    clr(); header("GYRO DATA")
    oled.text("X: " + str(values["gyro_x"]), 2, 14)
    oled.text("Y: " + str(values["gyro_y"]), 2, 26)
    oled.text("Z: " + str(values["gyro_z"]), 2, 38)
    footer("SEL=back")
    show()

SETTINGS_MENU = ["WiFi", "Date & Time"]

def page_settings_menu():
    clr(); header("SETTINGS")
    for i, item in enumerate(SETTINGS_MENU):
        y = 18 + i * 14
        if i == settings_sel:
            oled.fill_rect(0, y - 1, W - 4, 11, 1)
            oled.text(">" + item, 2, y, 0)
        else:
            oled.text(" " + item, 2, y)
    footer("SEL=enter LT=back")
    show()

def page_wifi():
    clr(); header("WIFI")
    try:
        sta = network.WLAN(network.STA_IF)
        if sta.isconnected():
            oled.text("SSID: " + _wifi_ssid[:10], 2, 14)
            oled.text("IP: " + sta.ifconfig()[0], 2, 26)
            oled.text("Status: online", 2, 38)
        else:
            oled.text("SSID: " + _wifi_ssid[:10], 2, 14)
            oled.text("Status: offline", 2, 26)
    except:
        oled.text("WiFi error", 2, 20)
    footer("SEL=back")
    show()

def page_datetime():
    clr(); header("DATE & TIME")
    t = time.localtime(time.time() - 7 * 3600)  # AZ = UTC-7
    if t[0] >= 2024:
        oled.text("{:02d}/{:02d}/{:04d}".format(t[1], t[2], t[0]), 12, 16)
        oled.text("{:02d}:{:02d}:{:02d}".format(t[3], t[4], t[5]), 24, 30)
        oled.text("AZ time (UTC-7)", 0, 43)
    else:
        oled.text("Syncing...", 24, 28)
    footer("SEL=back")
    show()

def page_sysinfo():
    import gc, esp
    from machine import freq as cpu_freq
    import os
    u = os.uname()
    lines = [
        "Chip: ESP32-S3",
        "Flash: {}MB".format(esp.flash_size() // (1024*1024)),
        "CPU: {}MHz".format(cpu_freq() // 1000000),
        "Free: {}B".format(gc.mem_free()),
        "Used: {}B".format(gc.mem_alloc()),
        "FW: " + u.version[:10],
        "UART: 9600 8N1",
        "OLED: 128x64 I2C",
        "ID: 0x43 (C)",
    ]
    vis = 5
    clr(); header("SYSTEM INFO")
    for i in range(vis):
        idx = i + _sysinfo_scroll
        if idx >= len(lines): break
        oled.text(lines[idx][:15], 0, 12 + i * 9)
    # scrollbar on right
    if len(lines) > vis:
        track_h = 42
        bar_h = max(4, vis * track_h // len(lines))
        bar_y = 12 + _sysinfo_scroll * (track_h - bar_h) // max(1, len(lines) - vis)
        oled.rect(124, 12, 4, track_h, 1)
        oled.fill_rect(124, bar_y, 4, bar_h, 1)
    footer("UP/DN SEL=back")
    show()

SETTINGS_MENU = ["WiFi", "Date & Time", "System Info"]

SETTINGS_SUBPAGES = [page_wifi, page_datetime, page_sysinfo]

def page_tx_monitor():
    clr(); header("TX MONITOR")
    # big indicator on left, label inline on right
    ix, iy = 4, 15
    oled.rect(ix,     iy,     20, 20, 1)   # outer ring
    oled.rect(ix + 4, iy + 4, 12, 12, 1)  # inner ring
    if tx_enabled:
        oled.fill_rect(ix + 7, iy + 7, 6, 6, 1)  # dot = on
    status = "ON " if tx_enabled else "OFF"
    oled.text("TX",    30, 17)
    oled.text(status,  30, 27)
    # speed and dir at bottom
    spd = abs(motor_speed)
    dr  = "FWD" if motor_speed >= 0 else "REV"
    oled.text("Spd:{:3d}%  {}".format(spd, dr), 0, 46)
    footer("SEL=toggle LT=back")
    show()

SUBPAGES = [page_motor, page_values, page_env, page_camera, page_distance, page_gyro, page_tx_monitor, None, page_settings_menu]

def _rand_food(snake, cols, rows):
    while True:
        x = random.randint(0, cols - 1)
        y = random.randint(0, rows - 1)
        if (x, y) not in snake:
            return (x, y)

async def snake_game():
    global in_sub
    CELL = 4
    COLS = W // CELL   # 32
    ROWS = H // CELL   # 16

    snake = [(COLS//2, ROWS//2), (COLS//2-1, ROWS//2), (COLS//2-2, ROWS//2)]
    direction = (1, 0)
    food = _rand_food(snake, COLS, ROWS)
    score = 0
    speed_ms = 200
    _last_move = time.ticks_ms()

    def draw():
        clr()
        for (x, y) in snake:
            oled.fill_rect(x*CELL, y*CELL, CELL-1, CELL-1, 1)
        oled.fill_rect(food[0]*CELL, food[1]*CELL, CELL-1, CELL-1, 1)
        oled.text(str(score), 0, 0)
        show()

    draw()

    while True:
        # steer - cant reverse
        if pressed('up')  and direction != (0,  1): direction = (0, -1)
        if pressed('dn')  and direction != (0, -1): direction = (0,  1)
        if pressed('lt')  and direction != (1,  0): direction = (-1, 0)
        if pressed('rt')  and direction != (-1, 0): direction = (1,  0)
        if pressed('stop') or pressed('sel'):
            break

        now = time.ticks_ms()
        if time.ticks_diff(now, _last_move) >= speed_ms:
            _last_move = now
            hx, hy = snake[0]
            nx, ny = hx + direction[0], hy + direction[1]

            if nx < 0 or nx >= COLS or ny < 0 or ny >= ROWS:
                break
            if (nx, ny) in snake:
                break

            snake.insert(0, (nx, ny))
            if (nx, ny) == food:
                score += 1
                food = _rand_food(snake, COLS, ROWS)
                speed_ms = max(60, speed_ms - 8)  # get faster
            else:
                snake.pop()
            draw()

        await asyncio.sleep_ms(20)

    # game over
    clr()
    oled.text("GAME OVER", 24, 18)
    oled.text("Score: " + str(score), 28, 32)
    oled.text("SEL=back", 32, 46)
    show()
    # wait for button
    while not pressed('sel') and not pressed('stop'):
        await asyncio.sleep_ms(50)
    in_sub = False
    draw_menu()

_BOUNCE = [0, -2, -4, -5, -4, -2, 0, 0]

async def anim_on():
    for frame in range(24):
        clr()
        oled.text("Turning on", 24, 18)  # centered: (128-80)/2=24
        for d in range(3):
            phase = (frame + d * 3) % len(_BOUNCE)
            y = 36 + _BOUNCE[phase]
            oled.fill_rect(45 + d * 16, y, 6, 6, 1)
        show()
        await asyncio.sleep_ms(70)
    flush_btns()
    draw_menu()

async def anim_off():
    clr()
    oled.text("Thank you.", 24, 12)   # (128-80)/2=24
    oled.text("Team 305",  32, 27)   # (128-64)/2=32
    oled.text("Christo",   36, 42)   # (128-56)/2=36
    show()
    await asyncio.sleep_ms(2000)
    for i in range(0, H + 8, 4):  # wipe down
        clr()
        oled.fill_rect(0, H - i, W, i, 1)
        show()
        await asyncio.sleep_ms(40)
    clr(); show()
    flush_btns()

def draw_debug():
    clr(); header("DEBUG")
    oled.text("T:{} H:{}".format(values["temp"], values["humid"]), 2, 13)
    oled.text("D:{} M:{}".format(values["distance"], values["motion"]), 2, 23)
    oled.text("GX:{} GY:{} GZ:{}".format(values["gyro_x"], values["gyro_y"], values["gyro_z"]), 0, 33)
    oled.text(("RX:" + last_rx_raw)[:18], 0, 43)
    footer("DBG again=exit")
    show()

def enter_debug():
    global debug_mode
    debug_mode = True
    led_debug.value(1)
    draw_debug()
    print("DBG T={} H={} D={} M={} GX={} GY={} GZ={}".format(
        values["temp"], values["humid"], values["distance"], values["motion"],
        values["gyro_x"], values["gyro_y"], values["gyro_z"]))

def exit_debug():
    global debug_mode
    debug_mode = False
    led_debug.value(0)
    if lcd_on:
        if not in_sub:
            draw_menu()
        elif sel == 3 and in_settings_sub:
            SETTINGS_SUBPAGES[settings_sel]()
        elif sel == 3:
            page_settings_menu()
        else:
            SUBPAGES[sel]()

# daisy chain protocol
MY_ID    = 0x43   # my id, 'C'
BCAST    = 0x58   # broadcast
RESERVED = (0x41, 0x5A, 0x59, 0x42)  # prefix/suffix bytes

_buf = bytearray()
_last_motor_send = 0

def build_packet(receiver_id, msg_type, data_bytes=b''):
    pkt = bytearray(64)
    pkt[0] = 0x41  # prefix
    pkt[1] = 0x5A
    pkt[2] = MY_ID
    pkt[3] = receiver_id
    pkt[4] = msg_type
    for i, b in enumerate(data_bytes):
        if 5 + i >= 62:
            break
        pkt[5 + i] = b
    # mask reserved bytes in data section
    for i in range(4, 62):
        if pkt[i] in RESERVED:
            pkt[i] = (pkt[i] - 1) & 0xFF
    pkt[62] = 0x59  # suffix
    pkt[63] = 0x42
    return pkt

def _forward(pkt):
    global _pkt_fwd
    _pkt_fwd += 1
    led_tx.value(1)
    uart.write(pkt)
    led_tx.value(0)

def _send_ack(dest, received_type):
    pkt = build_packet(dest, 0xAA, bytes([received_type]))
    led_tx.value(1)
    uart.write(pkt)
    led_tx.value(0)

def _handle_msg(msg_type, data):
    global last_rx_type
    last_rx_type = '{:02X}'.format(msg_type)

    if msg_type == 0x02:        # temp/humid from Isaiah
        values["temp"]  = data[0]
        values["humid"] = data[1]
    elif msg_type == 0x03:      # camera from Arianna
        values["motion"]      = data[0]
        values["object_code"] = data[1]
    elif msg_type == 0x04:      # gyro from Liam
        values["gyro_x"] = data[0] if data[0] < 128 else data[0] - 256
        values["gyro_y"] = data[1] if data[1] < 128 else data[1] - 256
        values["gyro_z"] = data[2] if data[2] < 128 else data[2] - 256
    elif msg_type == 0x05:      # distance from Myles
        values["distance"] = data[0]

    # refresh whichever page is open
    if lcd_on and in_sub:
        if msg_type == 0x02 and sel in (1, 2):
            page_values() if sel == 1 else page_env()
        elif msg_type == 0x03 and sel in (1, 3):
            page_values() if sel == 1 else page_camera()
        elif msg_type == 0x04 and sel in (1, 5):
            page_values() if sel == 1 else page_gyro()
        elif msg_type == 0x05 and sel in (1, 4):
            page_values() if sel == 1 else page_distance()

def parse_uart():
    global last_rx_raw, _buf, _pkt_rx, _pkt_drop
    while uart.any():
        b = uart.read(1)
        if not b:
            break
        byte = b[0]

        if len(_buf) == 0:
            if byte == 0x41:
                _buf.append(byte)
        elif len(_buf) == 1:
            if byte == 0x5A:
                _buf.append(byte)
            else:
                _buf = bytearray()
                if byte == 0x41:
                    _buf.append(byte)
        else:
            _buf.append(byte)
            if len(_buf) == 64:
                if _buf[62] == 0x59 and _buf[63] == 0x42:
                    _pkt_rx += 1
                    pkt      = bytes(_buf)
                    sender   = pkt[2]
                    receiver = pkt[3]
                    msg_type = pkt[4]
                    data     = pkt[5:62]

                    last_rx_raw = ' '.join('{:02X}'.format(x) for x in pkt[:8])

                    led_rx.value(1)
                    if sender == MY_ID:
                        pass  # loopback, ignore
                    elif receiver == MY_ID:
                        _handle_msg(msg_type, data)
                        _send_ack(sender, msg_type)
                    elif receiver == BCAST:
                        _handle_msg(msg_type, data)
                        _forward(pkt)
                    else:
                        _forward(pkt)  # not for me, pass it along
                    led_rx.value(0)
                else:
                    _pkt_drop += 1
                _buf = bytearray()

def send_motor_speed():
    global _last_motor_send
    if not tx_enabled:
        return
    now = time.ticks_ms()
    if time.ticks_diff(now, _last_motor_send) < 500:
        return
    if uart.any():
        return
    _last_motor_send = now
    spd = max(-100, min(100, motor_speed))
    if spd == 0:
        return
    pkt = build_packet(LIAM_ID, 0x01, bytes([spd & 0xFF]))
    led_tx.value(1)
    uart.write(pkt)
    led_tx.value(0)

async def uart_task():
    while True:
        parse_uart()
        send_motor_speed()
        await asyncio.sleep_ms(5)

# connect wifi and sync time
async def wifi_task():
    global wifi_connected
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    sta.connect(_wifi_ssid, _wifi_pw)
    for _ in range(20):
        if sta.isconnected():
            break
        await asyncio.sleep(1)
    if sta.isconnected():
        wifi_connected = True
        print('WiFi connected:', sta.ifconfig()[0])
        try:
            ntptime.settime()
            print('NTP synced')
        except:
            print('NTP failed')
    else:
        print('WiFi failed')

async def hmi_loop():
    global lcd_on, _lcd_changed_at, tx_enabled, in_sub, in_values_sub, values_sel, in_settings_sub, settings_sel, _sysinfo_scroll, sel, motor_speed, motor_dir, debug_mode
    _last_refresh = 0
    clr(); show()

    while True:
        if pressed('dbg'):
            enter_debug() if not debug_mode else exit_debug()

        if debug_mode:
            for k in _prev: _prev[k] = _BTNS[k].value()
            parse_uart()
            await asyncio.sleep_ms(20)
            continue

        if pressed('start'):
            if not lcd_on:
                lcd_on = True; in_sub = False; in_values_sub = False; in_settings_sub = False
                _lcd_changed_at = time.ticks_ms()
                await anim_on()
            elif time.ticks_diff(time.ticks_ms(), _lcd_changed_at) > 1000:
                lcd_on = False; in_sub = False; in_values_sub = False; in_settings_sub = False
                await anim_off()

        if lcd_on:
            if not in_sub:
                if held('up'):  sel = (sel - 1) % len(MENU); draw_menu()
                if held('dn'):  sel = (sel + 1) % len(MENU); draw_menu()
                if pressed('sel'):
                    if sel == 7:
                        await snake_game()
                    else:
                        in_sub = True; SUBPAGES[sel]()
            elif sel == 6:  # tx monitor
                if pressed('sel'):
                    tx_enabled = not tx_enabled
                    page_tx_monitor()
                if pressed('lt'):
                    in_sub = False; draw_menu()
            elif sel == 8:  # settings submenu
                if in_settings_sub:
                    if pressed('sel'):
                        in_settings_sub = False
                        _sysinfo_scroll = 0
                        page_settings_menu()
                    if settings_sel == 2:  # sysinfo scrollable
                        if held('up'):
                            _sysinfo_scroll = max(0, _sysinfo_scroll - 1); page_sysinfo()
                        if held('dn'):
                            _sysinfo_scroll = min(4, _sysinfo_scroll + 1); page_sysinfo()
                    now = time.ticks_ms()
                    if time.ticks_diff(now, _last_refresh) > 1000:
                        _last_refresh = now; SETTINGS_SUBPAGES[settings_sel]()
                else:
                    if pressed('lt'):
                        in_sub = False; draw_menu()
                    if held('up'):
                        settings_sel = (settings_sel - 1) % len(SETTINGS_MENU)
                        page_settings_menu()
                    if held('dn'):
                        settings_sel = (settings_sel + 1) % len(SETTINGS_MENU)
                        page_settings_menu()
                    if pressed('sel'):
                        in_settings_sub = True
                        SETTINGS_SUBPAGES[settings_sel]()
            else:
                if pressed('sel'): in_sub = False; draw_menu()
                if sel == 0:  # motor control
                    changed = False
                    if held('up'):
                        if motor_dir == "FWD":
                            motor_speed = min(100, motor_speed + 5)
                        else:
                            motor_speed = max(-100, motor_speed - 5)
                        values["speed"] = "{}%".format(abs(motor_speed)); changed = True
                    if held('dn'):
                        if motor_dir == "FWD":
                            motor_speed = max(0, motor_speed - 5)
                        else:
                            motor_speed = min(0, motor_speed + 5)
                        values["speed"] = "{}%".format(abs(motor_speed)); changed = True
                    if pressed('lt'):
                        motor_dir = "REV"
                        motor_speed = -abs(motor_speed)
                        changed = True
                    if pressed('rt'):
                        motor_dir = "FWD"
                        motor_speed = abs(motor_speed)
                        changed = True
                    if changed: page_motor()

        parse_uart()
        await asyncio.sleep_ms(20)

async def main():
    asyncio.create_task(wifi_task())
    asyncio.create_task(hmi_loop())
    asyncio.create_task(uart_task())
    while True:
        await asyncio.sleep(60)

try:
    asyncio.run(main())
finally:
    asyncio.new_event_loop()
